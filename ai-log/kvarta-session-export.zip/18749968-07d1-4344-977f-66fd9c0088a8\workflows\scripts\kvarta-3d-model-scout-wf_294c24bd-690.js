export const meta = {
  name: 'kvarta-3d-model-scout',
  description: 'Find free, licence-clean, ready-made 3D models (glTF/GLB) for a coffee roastery landing: bean, bag, mug, vehicle, city. Research only, no downloads.',
  phases: [{ title: 'Scout', detail: 'one researcher per asset category' }],
}

const S = { type: 'string' }
const CAND = {
  type: 'object',
  properties: {
    name: S, pageUrl: S, directDownloadUrl: S, loginRequired: { type: 'boolean' }, license: S, author: S,
    formats: { type: 'array', items: S }, triangles: S, fileSize: S, pbrTextures: S, whyItFits: S, risks: S,
  },
  required: ['name', 'pageUrl', 'directDownloadUrl', 'loginRequired', 'license', 'author', 'formats', 'triangles', 'fileSize', 'whyItFits', 'risks'],
}
const OUT = {
  type: 'object',
  properties: { category: S, candidates: { type: 'array', items: CAND }, recommendation: S, searchedSources: { type: 'array', items: S } },
  required: ['category', 'candidates', 'recommendation', 'searchedSources'],
}

const CONTEXT = `
Контекст: сайт небольшой обжарки кофе «Кварта» (Минск). На странице будет интерактивная WebGL-сцена: вращающееся зерно кофе, кофейная пачка, кружка, доставочный фургон/курьер, маленький город с домом. Нужны ГОТОВЫЕ красивые 3D-модели, не самодельные. Модели пойдут в публичный сайт, возможно коммерческий (клиент, пусть вымышленный, это бизнес), поэтому лицензия обязана разрешать коммерческое использование и показ на сайте: приоритет CC0, затем CC-BY (с обязательным указанием автора), НЕ брать NC/ND, НЕ брать «royalty-free с лицензией магазина, запрещающей перераздачу файла» без явной оговорки в риске.
Жёсткие правила исследования:
- Ты ТОЛЬКО ищешь и читаешь веб-страницы (инструменты WebSearch и WebFetch; сначала загрузи их через ToolSearch: select:WebSearch,WebFetch). НИЧЕГО не скачивай, не сохраняй файлы, не запускай curl/wget на файлы моделей.
- Для каждого кандидата открой его страницу и прочитай ТОЧНУЮ лицензию и автора. Не угадывай по памяти. Если не смог подтвердить лицензию, пиши «не подтверждена» и опиши в рисках.
- Выясни, можно ли скачать файл БЕЗ логина/аккаунта по прямой ссылке (loginRequired=false и directDownloadUrl). Sketchfab почти всегда требует логин для скачивания: в этом случае loginRequired=true.
- Формат: идеально glTF/GLB. Укажи размер файла и число треугольников, если есть на странице (иначе «не указано»).
- Приоритет источников без логина: Poly Haven (CC0), Kenney (CC0), Quaternius (CC0), Poly Pizza (CC0/CC-BY, там есть прямые ссылки на .glb), KhronosGroup glTF-Sample-Assets, Smithsonian 3D, OpenGameArt. Затем Sketchfab (CC0/CC-BY) как запасной вариант.
- Верни до 4 лучших кандидатов, по убыванию пригодности, и краткую рекомендацию. Честно отмечай, если реалистичных вариантов без логина нет.
`

const TASKS = [
  { key: 'bean', prompt: `${CONTEXT}\nКАТЕГОРИЯ: кофейное зерно. Нужна детальная модель ОДНОГО обжаренного кофейного зерна (с характерной бороздкой, реалистичная поверхность) или набора зёрен, которую можно размножить и вращать. Ищи также «coffee beans» кучку как запасной вариант. Реалистичность важнее низкого поли, но модель должна быть разумного размера для мобильного сайта (идеально до 3 МБ файл, до 60 тыс. треугольников).` },
  { key: 'bag', prompt: `${CONTEXT}\nКАТЕГОРИЯ: кофейная пачка/пакет. Нужна модель упаковки для кофе (крафт-пакет с клапаном, стоячий пакет doypack, бумажный пакет), чтобы на неё можно было наложить свою этикетку (желательно с понятной UV-развёрткой этикетки или отдельным материалом). Реалистичность и аккуратные детали (клапан, шов, складки) важны.` },
  { key: 'mug', prompt: `${CONTEXT}\nКАТЕГОРИЯ: кружка/чашка и подача. Нужна красивая керамическая кружка или чашка для кофе (желательно со внутренней поверхностью, чтобы можно было анимировать уровень кофе отдельной геометрией), плюс опционально гусиная шея (gooseneck kettle) или воронка V60/дриппер. Реалистичные PBR-материалы приветствуются.` },
  { key: 'vehicle', prompt: `${CONTEXT}\nКАТЕГОРИЯ: транспорт доставки. Нужна красивая модель курьерского фургона (small delivery van) ИЛИ курьера на велосипеде/грузовом велосипеде/скутере с коробом. Стиль может быть стилизованный low-poly, но аккуратный и узнаваемый; колёса желательно отдельными узлами, чтобы они вращались. Подойдёт набор вроде Kenney Car Kit / Quaternius, если там есть фургон доставки.` },
  { key: 'city', prompt: `${CONTEXT}\nКАТЕГОРИЯ: город и дома. Нужен набор готовых зданий и дорожных тайлов в одном аккуратном стиле (Kenney City Kit, Quaternius Town/City, Poly Pizza houses): жилые дома с дверями и окнами, небольшие магазины, дорожные тайлы/перекрёстки, деревья, мост или река если есть. Желательно CC0 и в виде отдельных GLB, чтобы взять только нужные. Укажи, из каких именно файлов набора брать дом с красной крышей и дверью, пару многоэтажек, магазин, дорогу, перекрёсток, дерево.` },
]

phase('Scout')
const results = await parallel(TASKS.map(t => () =>
  agent(t.prompt + '\nВерни результат строго по схеме.', { label: `scout:${t.key}`, phase: 'Scout', schema: OUT })))
return results.filter(Boolean)
